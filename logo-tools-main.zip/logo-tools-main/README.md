# Logo-Generate-Bot 

![🍀 Logo Generate Tools 🍀](https://telegra.ph/file/61e5a2d1009c4cbdaf67d.jpg)



## 🛠 Configuring Environments

``` API_HASH ``` Your Api Hash, Generate It From [TG API BOT](https://t.me/TgApiextractorBot)

``` API_ID ``` You Api Id, Generate It From [TG API BOT](https://t.me/TgApiextractorBot)

``` BOT_TOKEN ``` You bot token, Generate It From [Bot Father](https://t.me/BotFather)



## How To Deploy Bot (Watch On YouTube)🌷
[![ YouTube ](https://telegra.ph/file/04f4e08d3d96e237b6bad.jpg)](https://youtu.be/SEzZTL2eQ6k)



# Deploy Heroku 

[![Deploy](https://telegra.ph/file/bcf6fbca3700a360645d7.jpg)](https://heroku.com/deploy?template=https://github.com/SL-Bot-Developers/logo-tools.git)

# 📚 Description 📚
 

- 🔑 BOT Commands : `/start`, `/logo`, `/logohq`, `/write`, `/wall`



# 🌸 Demo Bot


[![🍀 Logo Generate Bot 🍀](https://telegra.ph/file/f593b501ef80a573d6cdf.jpg)](https://t.me/The_logo_generate_bot)


# 🔥 Developers 🔥

[![Chamod Deshan ](https://telegra.ph/file/51d4f585cc318baed6093.jpg)](https://t.me/chamod_deshan)
[![Bimsara malinga ](https://telegra.ph/file/66d4d94323712adcbd619.jpg)](https://t.me/bimsaramalinga)



## 🌷 Telegram Group/Channel

[![ SL Bot Developers ](https://telegra.ph/file/8d2ce03f6e28d9df777bb.jpg)](https://t.me/SL_BotDevelopers)
[![zoneunlimited ](https://telegra.ph/file/a08c7185f0f836d8a6f0f.jpg)](https://t.me/zoneunlimited) 



# 🙋‍♂ Credits 

[![ Single Developers ](https://telegra.ph/file/2780f811d0f1231fc8801.jpg)](https://t.me/SingleDevelopers)

##

